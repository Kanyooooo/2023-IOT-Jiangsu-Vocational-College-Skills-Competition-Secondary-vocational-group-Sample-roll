package com.example.a20221026sbrh1;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.nle.mylibrary.enums.led.PlayType;
import com.nle.mylibrary.enums.led.ShowSpeed;
import com.nle.mylibrary.forUse.led.LedScreen;
import com.nle.mylibrary.forUse.mdbus4017.MD4017;
import com.nle.mylibrary.forUse.mdbus4017.MD4017ValConvert;
import com.nle.mylibrary.forUse.mdbus4017.MD4017ValListener;
import com.nle.mylibrary.forUse.mdbus4017.Md4017VIN;
import com.nle.mylibrary.forUse.mdbus4150.Modbus4150;
import com.nle.mylibrary.transfer.DataBusFactory;

public class MainActivity extends AppCompatActivity {
    TextView noise_tv, temp_tv, hum_tv, co2_tv, state_tv;
    Button start_bt, stop_bt, send_bt;

    MD4017 md4017;
    LedScreen ledScreen;
    Handler handler;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        noise_tv = findViewById(R.id.noise_tv);
        temp_tv = findViewById(R.id.temp_tv);
        hum_tv = findViewById(R.id.hum_tv);
        co2_tv = findViewById(R.id.co2_tv);
        state_tv = findViewById(R.id.state_tv);
        start_bt = findViewById(R.id.start_bt);
        stop_bt = findViewById(R.id.stop_bt);
        send_bt = findViewById(R.id.send_bt);

        ledScreen = new LedScreen(DataBusFactory.newSocketDataBus("10.11.11.16", 6002));
        md4017 = new MD4017(DataBusFactory.newSocketDataBus("10.11.11.16", 6004));


        start_bt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                b = true;
            }
        });

        stop_bt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                b = false;
            }
        });

        send_bt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    ledScreen.sendTxt(vals[0] +Md4017VIN.TEM.getUnit()+"      "+
                            vals[1] +Md4017VIN.HUM.getUnit()+"      "+
                            vals[2] +Md4017VIN.CO2.getUnit()+"      "+
                            vals[3] +"db      ", PlayType.LEFT, ShowSpeed.SPEED1,0,999);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
        handler = new Handler();
        handler.post(runnable);
    }

    boolean b = true;
    double vals[] = new double[4];
    Runnable runnable = new Runnable() {
        @Override
        public void run() {
            if (b == true) {
                try {
                    md4017.getVin(new MD4017ValListener() {
                        @Override
                        public void onVal(int[] ints) {
                            vals[0] = MD4017ValConvert.getRealValByType(Md4017VIN.TEM, ints[0]);
                            vals[1] = MD4017ValConvert.getRealValByType(Md4017VIN.HUM, ints[1]);
                            vals[2] = MD4017ValConvert.getRealValByType(Md4017VIN.CO2, ints[2]);
                            vals[3] = MD4017ValConvert.getRealValByType(Md4017VIN.AIR, ints[3]);
                            temp_tv.setText(vals[0] +Md4017VIN.TEM.getUnit());
                            hum_tv.setText(vals[1] +Md4017VIN.HUM.getUnit());
                            co2_tv.setText(vals[2] +Md4017VIN.CO2.getUnit());
                            noise_tv.setText(vals[3] +"db");
                        }
                    });
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
            handler.postDelayed(runnable, 2000);
        }
    };
}